import React, { Component } from 'react';

class Home extends React.Component{

	render(){
		return <div> This is my Home page</div>
	}

}


export default Home;