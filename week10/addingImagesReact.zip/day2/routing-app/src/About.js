import React, { Component } from 'react';

class About extends React.Component{

	render(){
		return <div> This is my About page</div>
	}

}


export default About;