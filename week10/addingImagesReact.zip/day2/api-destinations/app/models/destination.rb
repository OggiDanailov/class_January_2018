class Destination < ApplicationRecord

end
