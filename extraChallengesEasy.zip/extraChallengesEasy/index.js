// 1. Write a function that takes three arguments, adds them together and returns true if the sum is
// divisible by three; returns false if the sum is not divisible by three


// 2. Write a function that takes and array of numbers and adds the sum of them.

// 3. Write a function that takes a string argument and returns all the instances of vowels

// 4. Write a function that lists all the numbers from 100 to 10; write it recursively

// 5. write a small program that checks the sum of two numbers.
// If the result is even:
// 	if also the result is divisible by 5 console.log('divisible by 5 and even')
// 	if also rhe result is divisible by 6 console.log('divisible by 6 and even')
// 	if also the result is divisible by both 5 and 6 console.log('divisible by 6 and 5 and it is even')
// If the result is odd:
// 	if it is divisible by 7 console.log('divisible by 7 and odd')
// 	if it is divisible by 9 console.log('divisible by 9 and odd')
// 	if it is divisible by both 7 and 9 console.log('divisible by noth 7 and 9')

// 6. Write a function that takes an array of numbers and creates a new array with 
// only the even numbers from the first array. For instance, 
// if you pass your function an array of [1, 3, 4, 6, 9, 10, 12, 13, 14], your function should return [4, 6, 10, 12, 14].

// 7. Write a function that gives you a random number between 1 to 100 in each second(setInterval).
// If the number is even console.log('this is even'); if the number is odd console.log('this is odd')


// 8. Write a function that takes a string and checks if the letter 'b' is there. Try to use indexOf() method.


// 9. write a function that checks if a given string is a palindrome.

// 10. write FizzBuzz recursivley

// 11. Write a function that takes the string "Boston is the capital of the US" as an argument and substitutes "Boston" 
// with "Washington". Try to use splice()


// 12. Create a function that takes in a string and returns a substring 4 characters long. Example:
// // subFunc("bullwinkle") -> "bull"

// 13. Create a function that takes in a string of multiple words and returns the first word with "ish" added to the end. Example:
// // ishFunc("Soup is my favorite.") -> "Soupish"

// 14. Create an array and show how to log each element to the console recursively.

// 15. Create an array. Using the .forEach() method on the array, print each element to
//  the console. If you are unsure on how to use .forEach(), Google.

// 16. Create an array. Create a function that takes an array as an argument and logs only the first element and last element to the console. Example:
// lastFirst(["dogs", "cats", "hamburger", "dinosaur"]) // dogs // dinosaur

// 17. // 1. Create a function that takes an array. Check to see if it contains a 5 or 6. If it does, return true, otherwise return false. Example:
// checkNums( [1, 3, 5, 12, 22] ) -> true //checkNums( [30, 99, 8, 22, 7] ) -> false

// 18. Create a function that takes an array. If an array element is equal to 5, set it to 0. Example:
// noFive( [2, 17, 5, 18, 6, 5] ) -> [2, 17, 0, 18, 6, 0]














